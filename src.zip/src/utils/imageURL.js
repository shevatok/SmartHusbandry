// const imgUrl = 'http://37.128.248.23:50458/downloadFile/';
const imgUrl = "http://114.9.13.243:8081/api";
// const imgUrl = 'http://localhost:8081/api/';

export default imgUrl;
