export default {
  monitor: (config) => {
    return {
      status: 1,
      message: "monitor",
    };
  }
}